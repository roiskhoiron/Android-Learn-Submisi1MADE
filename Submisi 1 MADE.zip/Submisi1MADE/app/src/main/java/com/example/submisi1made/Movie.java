package com.example.submisi1made;

import android.os.Parcel;
import android.os.Parcelable;

public class Movie implements Parcelable {
    private int banner;
    private String name;
    private String description;
    private String release;
    private String categoty;
    private String director;

    public Movie() {
    }



    public int getBanner() {
        return banner;
    }

    public void setBanner(int banner) {
        this.banner = banner;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRelease() {
        return release;
    }

    public void setRelease(String release) {
        this.release = release;
    }

    public String getCategoty() {
        return categoty;
    }

    public void setCategoty(String categoty) {
        this.categoty = categoty;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }


    protected Movie(Parcel in) {
        this.banner = in.readInt();
        this.name = in.readString();
        this.release = in.readString();
        this.categoty = in.readString();
        this.director = in.readString();
        this.description = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.banner);
        dest.writeString(this.name);
        dest.writeString(this.release);
        dest.writeString(this.categoty);
        dest.writeString(this.director);
        dest.writeString(this.description);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel source) {
            return new Movie(source);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };
}
