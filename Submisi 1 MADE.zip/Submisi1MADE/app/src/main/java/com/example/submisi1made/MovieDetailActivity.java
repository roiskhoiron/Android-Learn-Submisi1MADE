package com.example.submisi1made;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MovieDetailActivity extends AppCompatActivity {

    public static final String MOVIE_INDEX = "parcel movie";
    private TextView tvName, tvRelease, tvCategory, tvDirector, tvDesc;
    private ImageView imgvPhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_detail);

        tvName = findViewById(R.id.tv_name);
        tvRelease = findViewById(R.id.tv_release);
        tvCategory = findViewById(R.id.tv_category);
        tvDirector = findViewById(R.id.tv_dirrector);
        tvDesc = findViewById(R.id.tv_desc);
        imgvPhoto = findViewById(R.id.imgv_photo);


        Movie movieParcel = getIntent().getParcelableExtra(MOVIE_INDEX);

        tvName.setText(movieParcel.getName());
        tvRelease.setText(movieParcel.getRelease());
        tvCategory.setText(movieParcel.getCategoty());
        tvDirector.setText(movieParcel.getDirector());
        tvDesc.setText(movieParcel.getDescription());
        imgvPhoto.setImageResource(movieParcel.getBanner());
    }
}
